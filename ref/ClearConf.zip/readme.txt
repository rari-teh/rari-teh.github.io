CLEARCONF HELP FILE *******************************

INTRODUCTION

	ClearConf is a simple program written in
AutoHotkey that gives use to the clear key. In case
you don�t know what the clear key is (I wouldn�t
blame you), it is the name the numpad 5 key
receives when numlock is off. Typically, it does
absolutely nothing. The only use I can think of for
it is when you need to give the PC a �nudge�
without interfering with anything.

It is the successor of NumDoubleDown, a one-liner
that was basically ClearConf�s Lenovo mode. I made
it during my playthrough of DELTARUNE -- you can
guess why. The motivation for expanding it into
ClearConf was the annoyance of trying to find the k
key in the dark while trying to pause YouTube at
night. All other features were mere afterthoughts.

CLEARCONFN

	ClearConfn is exactly the same as
ClearConf, only with custom mode stripped off.

MODES

Lenovo mode
	Recently, the brilliant folks at Lenovo
	have come up with the best idea possible
	to save up some space on the keyboard on
	their ideapad laptops: cramming the up and
	down keys in the space of one key. It
	shouldn�t be needed to say that this
	ingenious idea made playing any game that
	needs moving around with the arrow keys
	irritatingly janky. You always have the
	alternative of playing with the numpad
	arrow keys, but that creates another
	problem: the down key, which is numpad 2
	with numlock off, is not on the same row
	than the left and right arrows, so your
	middle finger must curl inwards in order to
	press it. This mode is the solution to
	that: it makes the clear key behave like
	numpad down, so that you have a normal set
	of arrows on your numpad with numlock off.

	tl;dr: Clear behaves as numpad down key.

YouTube mode
	In this mode, the clear key is programmed
	to type the letter k. It is meant to make
	keyboard navigation on YouTube easier when
	travelling on 10 s intervals is too much.

Break mode
	The seldom useful Pause|Break key is being
	quietly discontinued on laptop keyboards.
	Most people are totally fine with it; I bet
	most didn�t even notice it has gone the
	ways of SysRq. But, Alas, seldom useful is
	still useful. In this mode, the clear key
	behaves like the break key.

	Due to a limitation, it seems not to be
	possible to make Ctrl+Alt+Break work with
	clear as break. However, Ctrl+Break does
	work.

Custom mode?
	If you want to give another meaning to the
	clear key and that meaning isn�t listed
	above, this mode is for you. The key name
	must be written in a format compliant to
	https://www.autohotkey.com/docs/KeyList.htm

Disable
	When ClearConf is disabled, the clear key
	will behave like itself.

COMMAND LINE SYNTAX

	clearconf dd  : Start on Lenovo mode
	clearconf yt  : Start on YouTube mode
	clearconf brk : Start on break mode
Any other first argument will make ClearConf start
on custom mode with the argument as the key. If the
argument isn�t a valid AutoHotkey name, the key
will not work until you switch modes. Any further
arguments are not considered.

LICENSE

	ClearConf is released in a CC-BY license.
This means you may do whatever you wish with it as
long as you credit me, rariteh.

ClearConf�s icons are based off DoCoMo�s 2002 emoji
set.

CHANGELOG

v1.1 (2019-09-22)
	- Added help file and source code
	- Some tweaks and small features

v1.0 (2019-09-21)
	Initial release