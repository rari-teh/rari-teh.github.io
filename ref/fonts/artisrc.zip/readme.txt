ARTITYPE FONT FAMILY
genotheta is (c) artifyber
the artitype fonts (and the entirely unofficial @ and $ characters) were made by rari_teh
you may use these fonts as you wish, provided that artifyber is cool with it and that you credit me for it

CHANGELOG
2026-05-07 (Version 4.0)
updated fonts according to the official expansions to genotheta
improved metrics

2025-08-08 (Version 3.0)
initial public release as part of KittyMath's source code

you may find me in every place listed at http://rarit.ee/contact.htm