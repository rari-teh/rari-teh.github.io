= DICE BLOCK TIMER FREEZE =
by rari_teh

This very simple hack freezes the timer on Dice Square/Dice Block,
allowing the game to be completed. If you want any more information,
check out my blogpost about the entire thing:
http://blog.rarit.ee/2023/02/puzzle-game-archeology-or-idiot-duck.html

Original ROMs:
Mega Duck: Mega Duck 4 in 1 (World).bin [No-Intro]
           035.bin [MAME] (in md4in1.zip)
	   CRC32 8046EA70
 Game Boy: 4 in 1 (Europe) (4B-002, Sachen) (Unl).gb [No-Intro]
           CRC32 5E438DB8